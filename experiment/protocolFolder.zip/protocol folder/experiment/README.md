This code is a patch-work of code written by myself and existing code from previous studies. Specifically, I used Ariel Zylberberg's code, originally used for experiment 1 in
*Zylberberg, A., Bartfeld, P., & Signman, M. (2012). The construction of confidence in percpetual decision. Frontiers in integrative neuroscience,6, 79.*
And The code used in 
*Fleming, S. M., Maniscalco, B., Ko, Y., Amendi, N., Ro, T., & Lau, H. (2015). Action-specific disruption of perceptual confidence. Psychological science, 26(1), 89-98.*

Adapted by Matan Mazor, 2018
